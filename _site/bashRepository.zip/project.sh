#!/bin/bash


#Made by Justas Jonas Labeikis
#Matriculation number: 180012794



make_repository () {								#Creates the repository
	read -p 'Please enter the name of the repository ' reponame
	if [ -f "$repo_names" ];then
		if grep -q "$reponame" "$repo_names";then
			echo "Name already exists!"
			return 1
		fi
	fi

	  if [[ "$reponame" == *"/"* ]]; then					#Prevents user from using the / symbol in the name
                        echo "Repository names cannot contain / symbol!"
			echo "..................................................."
                        return 1
          fi


	local cur_date=$(date +"%Y-%m-%d %T")


	read -p  "Are you sure you want to create a repository with the name $reponame ?(y/n) " answer
	
	while true; do
		case $answer in
			y)
			mkdir -p "${1}/${reponame}/.logs"	#Creates the repository
			mkdir -p "${1}/${reponame}/.backups"	#Creates the backup repository
			echo "${cur_date}: $username created repository" >> "${1}/${reponame}/.logs/log"	#Writes to main log
			echo -e "$reponame" >> $repo_names	#writes to file that contains all the repository names
			echo "Success!"
			echo "........................"
			break
			;;
			n)
			echo "Returning..."
			echo ".........................."
			break
			;;
			*)
			read -p "Invalid input, please enter y or n " answer
			;;
		esac
	done
}

backup_file ()				#Backs up the file
{
	local directory="$1"
	local file_name="$2"
	local backup_dir=".backups"
	local current_date="$3"

	mkdir -p "$repo_dir/$directory/$backup_dir/${file_name}_back" && cp "$repo_dir/$directory/$file_name" "$repo_dir/$directory/$backup_dir/${file_name}_back/${current_date}"	#Makes the directory for the file and copies it




}
update_file ()			#After an edit backups the file and lets the user comment on what he changed
{
	local directory="$1"
	local file_name="$2"
	local cur_date=$(date +"%Y-%m-%d %T")


	if [[ "$file_name" == *"/"* ]]; then		#Check for file name to not contain / symbols because they cause errors
		echo "Cannot update files with / symbols!"
		return 1

	fi
	while true; do
		read -p "Please enter any comments about the edits of file: " comment	#Reads the users input
		if [[ "$comment" == *"/"* ]];then
			echo "Cannot use / symbol in comments"
			continue
		fi
		break
	done
	       read -p  "Are you sure you wish to save this file with this comment?(y/n) " answer

        while true; do
                case $answer in
                        y)
                        echo "${cur_date}: $username edited ${file_name} with comments: $comment" >> "$repo_dir/$1/$repo_log"	#Writes to main log
                       	echo -n "${cur_date}//${comment}//" >> "$repo_dir/$1/$repo_log_dir/${file_name}-log"			#-n prevents new lines from being created
			backup_file "$directory" "$file_name" "$cur_date"							#Backs up file
                        echo "Success!"
			echo "..........................................."
                        break
                        ;;
                        n)
			if [[ "$3" = "edited" ]]; then				#If the file was edited inside the script then the user must enter a comment, so run the function again
                        	update_file "${directory}" "${file_name}" "edited"
			else
				echo "Returning..."
				echo ".............................."
			fi
                        break
                        ;;
                        *)
                        read -p "Invalid input, please enter y or n " answer
                        ;;
                esac
        done

}
find_array_index ()		#Finds the selected versions index in the array
{
	local action=true
	local item="$1"

	for var in "$@" ; do
	if [ $action = true ]; then
		local action=false
		continue
	fi
	local array+=("$var")
	done
	

	for x in "${!array[@]}"; do
		if [[ "${array[$x]}" = "${item}" ]];then
			echo "${x}"
		fi

	done




}
display_file_versions ()	#Displays the menu that lets the user choose which file to restore
{	
	local file_name="$1"
	local repo_name="$2"


	local action=true

	
	local log_path="$repo_dir/$repo_name/.logs/${file_name}-log"
	local full_text=$(cat "$log_path")
	local IFS='//'						#The delimiter symbol
	read -ra text <<< "$full_text"				#Read the text splitting it to arrays at the // symbol
	local IFS=' '
	for x in "${text[@]}"; do					#Splits the text to 2 arrays. One containing the text and the other the description
		if [ ! -z "$x" ];then					#Checks if the string is not empty, because for some reason it reads blank strings sometimes
			if [[ $action = true ]]; then
				local action=false
				local version_dates+=("$x")		#Array containing only verrsions
			else

				local action=true
				local descriptions+=("$x")		#Array contain only user comments
			fi
		fi
	done
	
	for y in ${!version_dates[@]}; do				#Makes a new array with dates and descriptions displayed to the user
		local full_versions+=("${version_dates[$y]} - ${descriptions[$y]}")
	
	done
	
 echo "Please select the version of $file_name you wish to restore"
	   

        select z in "${full_versions[@]}" "back"; do	#Creates the menu for the user to select which version they want to restore
                for ele in "${full_versions[@]}"; do
                if [[ $ele == $z ]]; then


			local index=$(find_array_index "$ele" "${full_versions[@]}")   #Gets the index of the selected version
                        local timenow="${version_dates[${index}]}"			#Gets date and time that the item was backed up
			local descNow="${descriptions[${index}]}"			#Gets the comment of the item
			restore_file "$timenow" "$repo_dir/$repo_name" "$file_name" "$descNow"	#Restores selected item
                        break 2
                fi
                done
                if [ "$z" = "back" ]; then
                echo "........................................"
                break
                fi
        done
}
restore_file ()						#Restores the selected file
{
	local fileTime="$1"
	local pathToRepository="$2"
	local fileName="$3"
	local fileDescription="$4"
	local cur_date=$(date +"%Y-%m-%d %T")
	
	 read -p  "Are you sure you wish to roll back the file to the version created at $fileTime? (y/n) " answer

        while true; do
                case $answer in
                        y)
			
			if [[ -f "$pathToRepository/.backups/${fileName}_back/$fileTime" ]]; then				#Checks if the backup of the file exists
				rm -f "$pathToRepository/$fileName"								#Removes original file
				cp "$pathToRepository/.backups/${fileName}_back/$fileTime" "$pathToRepository/${fileName}"	#Copies backup
				echo "${cur_date}: $username restored file $fileName to the version created at $fileTime" >> "$pathToRepository/$repo_log"	#Writes main log
				echo "Success!"
			else
				echo "Unable to find file backup. Cannot continue........"
				echo "Updating logs"
				echo "${cur_date}: unable to find a backup for $fileName at $fileTime" >> "$pathToRepository/$repo_log" #Writes main log
			fi
                        echo "........................"
                        break
                        ;;
                        n)
                        echo "Returning..."
                        echo ".........................."
                        break
                        ;;
                        *)
                        read -p "Invalid input, please enter y or n " answer
                        ;;
                esac
        done


}
remove_file ()		#Removes a selected file and all its backups
{
	local file_name="$1"
	local repo_name="$2"
	local cur_date=$(date +"%Y-%m-%d %T")



     read -p  "Are you sure you wish to delete $file_name and all it's backups?(y/n) " answer

        while true; do
                case $answer in
                        y)
                        rm "${repo_dir}/${repo_name}/${file_name}"       #Removes the file
			rm "${repo_dir}/${repo_name}/.logs/${file_name}-log" #Removes the file logs
			rm -rf "${repo_dir}/${repo_name}/.backups/${file_name}_back" #Removes all the backups
                        echo "${cur_date}: $username deleted file ${file_name}" >> "${repo_dir}/${repo_name}/.logs/log" #Writes the main log
                        echo "Success!"
                        echo "........................"
                        break
                        ;;
                        n)
                        echo "Returning..."
                        echo ".........................."
                        break
                        ;;
                        *)
                        read -p "Invalid input, please enter y or n " answer
                        ;;
                esac
        done


}
edit_file ()			#Let the user edit files
{
	local file_name="$1"
	local dir_name="$2"
	
	local path_to_file="${repo_dir}/${dir_name}"


	if [[ "$file_name" == *"/"* ]]			#Checks if the file doesnt contain / symbols
	then
		echo "Unable to edit files with / symbols!"
		return 1
	fi

	cp "${path_to_file}/$1" "${path_to_file}/.${1}-tmp"	#create a temporary copy that will help determine if the user made any edits to the file

	gedit "${path_to_file}/$1"		#Edit file with the gedit editor
	cmp --silent "${path_to_file}/.${1}-tmp" "${path_to_file}/$1" || update_file "${dir_name}" "${file_name}" "edited" #If cmp fails that means the files are different so there were changes made that need to be commented
	rm "${path_to_file}/.${1}-tmp"		#removes the temporary file
}

display_repo_item_select ()			#Displays all the files in the directory and let's the user choose what he wants. $1 is the directory name $2 is the action that the user wishes to do
{
	local check=$(ls "./repo/$1")	#Gets all the file names in the repository
	if [ -z "$check" ];then		#Check if the directory is not empty
		echo "Unable to do anything because the directory is empty!"
		echo "................................................."
		return 1
	fi

	files=( )	#creates an array		#Easiest way to do this would be to use ls and put everything to an array, but when doing so files with spaces are treated as separate files
	for i in "./repo/$1"/*		#For every item in the repository
	do
	files+=( "${i##*/}" ) 		#Add items to the array and remove the file path (not sure how hashing works) taken from stack overflow

	done
        echo "Please select a file: "
        select q in "${files[@]}" "back"; do		#Displays all items in the repository
                for f in "${files[@]}"; do
                if [[ "$f" == "$q" ]]; then
			if [ "$2" = "update" ]; then		#Depending on the argument given to the function decide what the user intends to do with the file
                        	update_file "$1" "$q"
			elif [[ "$2" = "backup" ]]; then
				if [[ -f "$repo_dir/$1/.logs/${q}-log" ]]; then	#Checks if there are any backups for the file
					display_file_versions "$q" "$1"
				else
					echo "No backups can be found of the file................."
				fi
			elif [[ "$2" = "delete" ]]; then
				remove_file "$q" "$1"
			elif [[ "$2" = "edit" ]]; then
				edit_file "$q" "$1"
			fi
                        break 2
                fi
                done
                if [[ $q == "back" ]]; then
                echo ".........................................."
                break
                fi
        done
}

print_log ()					#Prints the log of the repository if it exists (it should always exist because it's created when the repository is created)
{

	local repo_name="$1"
	local log_path="${repo_dir}/${repo_name}/${repo_log}"
	if [ -f "$log_path" ];then		#Check if the log exists
		cat "$log_path"
	else
		echo "Error unable to find log!"
	fi
	echo "......................................................"

}
get_zip_name ()						#Get the zip files versions name
{
	local dir="${1}"
	local name="${2}"

	local version=1

	while [ -f "${dir}/${name}V${version}.zip" ]	#While theree is a file with that name increment the number
	do
		local version=$((version+1))
	done
	echo "${name}V${version}"			#Print the correct zip name

}
zip_repo ()		#Zips all the files inside the repository (exluding folders)
{	
	local cur_date=$(date +"%Y-%m-%d %T")
	local repo_name="$1"
	local directory="./repo_zip/${repo_name}"		#Repositories directory
	if [ ! -d "$directory" ]; then				#Create zip directory if it does not exist
		echo "..................................."
		echo "Creating zip directory at script folder!"
		echo "......................................"
		mkdir -p "${directory}"
	fi
	if [[ $(ls -A "$directory") ]]; then		#Check if there already exist zip files in the directory
    		local name=$(get_zip_name "${directory}" "${repo_name}")	#Gets the correct zip name
		zip -j "${directory}/${name}" "${repo_dir}/${repo_name}"/*	#Creates the zip file
		
	else
		zip -j "${directory}/${repo_name}V1" "${repo_dir}/${repo_name}"/*	#Creates the zip file if its the 1st one
	fi
		echo "${cur_date}: $username zipped the project" >> "${repo_dir}/${repo_name}/.logs/log" #Writes the main log

}



display_repo_menu ()				#Displays the options for a repository. $1 is the name of the repository
{

	echo "What would you like to do?"

	while true; do				#Redisplays the options to the user after each input
        select action in "Create new file" "Edit file" "Update/backup a manually edited or created file" "Restore files older version" "Remove file and all it's logs" "Zip project" "Print out log of the repository" "back"
        do
        case $action in
		"Create new file")
			create_file "$1"
			break
			;;
		"Edit file")
                        display_repo_item_select "$1" "edit"
                        break
                        ;;
                        
                "Update/backup a manually edited or created file")
                        display_repo_item_select "$1" "update"
                        break
                        ;;
                "Restore files older version")
                        display_repo_item_select "$1" "backup"
                        break
                        ;;
		"Remove file and all it's logs")
			display_repo_item_select "$1" "delete"
			break
			;;
		"Zip project")
			zip_repo "$1"
			break
			;;
		"Print out log of the repository")
			print_log "$1"
			break
			;;
               	"back")
			echo "........................................"
                        break 2
                        ;;
               		 *)
                        echo "what?"
                        break
                        ;;
        esac
        done
        echo "Would you like to do anything else?"
done



}
create_file ()					#Creates a file at the repository with a chosen name
{
	local file_repo="$1"
	local repo_path="$repo_dir/$1/"
	local file_name
	local cur_date=$(date +"%Y-%m-%d %T")
	
	while [[ -z "$file_name" ]]                      #keep the while loop going till the user enter a name
	do
        	read -r -p 'Please enter the file name: ' file_name

		if [[ -z "$file_name" ]]; then
			echo "File name cannot be empty!"
		elif [[ "$file_name" == *"/"* ]] ;then
			echo "File names cannot contain a / symbol!"
			return 1
		fi
	done



	read -p "Create file with the name $file_name in ${file_repo}?(y/n) " answer
	while true; do
	case $answer in
                        y)
				touch "${repo_path}${file_name}"		#Creates the file
                        	echo "${cur_date}: $username created ${file_name}" >> "$repo_dir/$1/$repo_log"			#Writes main log
        	                echo -n "${cur_date}//File created!//" >> "$repo_dir/$1/$repo_log_dir/${file_name}-log"            #-n prevents new lines from being created and creates the files log
                	        backup_file "$file_repo" "$file_name" "$cur_date"						#Creates a backup for the file
				echo "Success"
				echo "................................................................."
                	        
                        break
                        ;;
                        n)
                        echo "Returning..."
                        echo ".........................."
                        break
                        ;;
                        *)
                        read -p "Invalid input, please enter y or n " answer
                        ;;
                esac
        done

}

display_repo_content () 			#Displays the contents of a repository $1 name of the repository
{
	local files=$(ls "$repo_dir/$1")

	
	if [ -z "$files" ]; then		#Check if there are files in the directory, if there aren't then ask the user if he wishes to add one
		echo "Directory empty"

	read -p "would you like to add a file?(y/n)" answer

	  while true; do
                case $answer in
                        y)
                        create_file "$1"	#Creates a file
                        echo "........................"
                        break
                        ;;
                        n)
                        echo "Returning..."
                        echo ".........................."
                        break
                        ;;
                        *)
                        read -p "Invalid input, please enter y or n " answer
                        ;;
                esac
        done

else							#If there are files in the repository, display them
        echo -e "Items inside the repository are:\n"
        repo_files=$(ls "$repo_dir/$1")
        echo $repo_files
        echo "................."
        display_repo_menu "$1"				#Show the options to the user

fi


}
update_repo_list ()			#When deleting a repository updates the repository list
{
	local repo_name="$1"

	cp "$repo_names" ".tmp"		#Copies the current repository list
	rm "./${repo_names}"		#Removes the current repository list

	while read line; do		#Read each line of the file
	if [[ "$line" == "$repo_name" ]];then
		continue			#skip the line that has the name that was deleted
	fi
	echo "${line}" >> "./${repo_names}"	#Writes everything to the new text file
	done < ".tmp"
	rm ".tmp"	#Removes the temporary file
	

}
delete_repo ()			#Deletes the repository choosen
{
	local repo_name="$1"

   read -p "Are you sure you wish to delete the repository with the name ${repo_name}?(y/n) " answer
          while true; do
                case $answer in
                        y)
                        rm -rf "${repo_dir}/${repo_name}"	#Removes the repository and everything inside
			update_repo_list "$repo_name"		#Updates the names
			echo "Success!"
                        echo "........................"
                        break
                        ;;
                        n)
                        echo "Returning..."
                        echo ".........................."
                        break
                        ;;
                        *)
                        read -p "Invalid input, please enter y or n " answer
                        ;;
                esac
        done


}
display_repo_list () 			#Display all of the repositories
{

if [ -f "$repo_names" ]; then
     	 mapfile -t names < "${repo_names}"          #Creates an array with all the names of the repositories
	echo "Please select a repository"
	select i in "${names[@]}" "back"; do
		for item in "${names[@]}"; do
		if [[ "$item" == "$i" ]]; then

			if [[ "$1" == "delete" ]];then
				delete_repo "$i"
			else
				display_repo_content "$i"
				
			fi
			break 2
		fi
		done
		if [[ $i == "back" ]]; then
		echo "........................"
		break
		fi
	done
else
	echo "No repositories found..."
fi



}
repo_log_dir="./.logs"
repo_log="./.logs/log"
repo_dir="./repo"				#location where all the repositories are going to be kept
repo_names=".Repository_info"			#lists all of the repositories that have been created
while [[ -z "$username" ]]			#keep the while loop going till the user enter a name
do
	read -r -p 'Please enter your name: ' username
done
echo "Hello $username what would you like to do?"


while true; do		#The main loop of the script. Will keep going untill the user decides to quit. The while loop redisplays the message to the user.
	select action in "Make new repository" "List all repositories" "Delete a repository" quit
	do
	case $action in
		"Make new repository")
			make_repository "$repo_dir"
			break
			;;
		"List all repositories")
			display_repo_list
			break
			;;
		"Delete a repository")
			display_repo_list "delete"

			break
			;;
		quit)
			break 2
			;;
		*)
			echo "what?"
			break
			;;
	esac
	done
	echo "Would you like to do anything else?"
done
echo "end"
