import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Contains methods for the hashMaps used for the dictionary
 */
public class Translation 
{
	private HashMap<String, String> dictionary;
	private String inputFile;
	
	
	
	
	public HashMap<String, String> getDictionary() {
		return dictionary;
	}

	public Translation(String fileName)
	{
		dictionary = new HashMap<String, String>();
		inputFile = fileName;
		loadFile();
	}
	
	public void addToHashMap(String word, String meaning)
    {
        // Make word and meaning lower case
        word = word.toLowerCase();
        meaning = meaning.toLowerCase();

        // Add a word to the dictionary
        dictionary.put(word, meaning);
    }
	
	public String getTranslation(String word)
	{
		String meaning;
		// Get translated word
		meaning = dictionary.get(word);
		return meaning;
	}
	
	/**
	 * this method enables the user to specify the file it wants to copy text from
	 * after the text is copied it is then displayed on the screen
	 * if there is any error in the code the try...catch block will identify it and prompt the user or the programmer
	 */
	public void loadFile() 
	{
		
		if(fileExistence(inputFile))
		{
			FileReader fileReader = null;
			BufferedReader bufferedReader = null;
			
			//try copying the node details from the Sample file if verified to exist
			//and there are no errors to be caught
			try 
			{
				
				fileReader = new FileReader(inputFile);
				bufferedReader = new BufferedReader(fileReader);
				
				String nextLine = bufferedReader.readLine();
				
				String delimiter = "//";
				
				
				//loop until there is no line of details to copy
				while(nextLine!=null) 
				{
					String [] words = nextLine.split(delimiter);
					//this allocates the English as the key and the French words as the value
					//dictionary.put(words[0], words[1]);
					
					addToHashMap(words[0], words[1]);
					
					nextLine = bufferedReader.readLine();
				}
				bufferedReader.close();
			}catch (IOException e) 
			{
				// TODO Auto-generated catch block
				System.out.println("The error is: "+e);
			}
		}
		
	}

	/**
	 * this method verifies whether the specified file exists or not
	 * if it exists it prompts the user that the file exists,
	 * if it does not exist then the user is prompted that the file does not exist
	 * @param file the specified file name
	 * @return true if file exists
	 * @return false if file doesn't exist
	 */
	public boolean fileExistence(String file) 
	{
		FileReader fileReader= null;
		BufferedReader bufferedReader= null;
		//try checking if the file exists already if it exists return right and if not return wrong
		try {
			fileReader = new FileReader(file);
			bufferedReader = new BufferedReader(fileReader);
			bufferedReader.close();
			return true;
				
		}catch (IOException e) 
		{

			return false;
		}
	}
	/**
	 * This method is used to write the shop items to the sample file until there is no longer any node to write to the file 
	 * if there is any error in the code the try...catch block will identify it and prompt the user or the programmer
	 * @param append boolean that decides whether to append the text or overwrite it
	 * @param key the new text
	 */
	public void saveToFile(Boolean append, String key) 
	{
		PrintWriter printWriter= null;
		FileOutputStream outputStream= null;
		
		
	    
		//try writing the node details to the Sample file
		//if there are no errors to be caught
		try 
		{
			outputStream = new FileOutputStream(inputFile, append);
			printWriter = new PrintWriter(outputStream);
			
	
			if(key.equals(""))
			{
				// an Iterator for the set
			    Iterator<String> iterator = dictionary.keySet().iterator();
				
				// while there is another item in the set to iterate over
				while (iterator.hasNext())
				{
					
					
					// get the next String in the map
					String n = iterator.next();
					// get the next String in the map
					String m= dictionary.get(n);
			           
					//prints out the words in the HashMap to the document
					printWriter.println(n+"//"+m);
				}
			}
			else
			{

				printWriter.println(key+"//"+dictionary.get(key));
				
			}
			printWriter.close();
		} catch (FileNotFoundException e) 
		{
			// TODO Auto-generated catch block
			System.out.println("The error is: " + e);
		}
	}
	
	/**
	 * This method deletes specified words from the dictionary
	 * @param key String of specific word to be deleted form the dictionary HashMap
	 */
	public void deleteFromMap(String key) {
		dictionary.remove(key);
	}
	public boolean hasWord(String word)
	{
		return dictionary.containsKey(word);
		
		
	}
}
