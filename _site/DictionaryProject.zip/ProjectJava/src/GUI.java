import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.border.Border;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 * Creates the GUI for various tasks
 * @author Justas Labeikis
 *
 */
public class GUI implements ItemListener {
	private JFrame window; //the main window
	private JPanel topPanel; //layout of the window
	private final static Border defaultBorder = BorderFactory.createLineBorder(Color.BLACK, 1); //the default boarder used for buttons, labels
	private Font buttonFont = new Font("Courier New", Font.ITALIC, 20); //the font used for the buttons
	private Font textBoxFont = new Font("Courier New", Font.PLAIN, 18);  //font for text in user inputs
	private TextTranslation dictionary; //the dictionary
	private boolean checkBox = false; //decides if the checkbox is true or false
	private JLabel timerLabel; //the label for the time to translate
	
	
	/**
	 * Main constructor
	 * @param translate the dictionary
	 */
	public GUI(TextTranslation translate)
	{
		dictionary = translate;
		
		window = new JFrame();
		
		topPanel = new JPanel();
		topPanel.setLayout(new BorderLayout());
		topPanel.add(mainMenu(), BorderLayout.CENTER);
		topPanel.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
		 window.setContentPane(topPanel);  // set topPanel as the content pane of this window
		 window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // when window is closed, terminate the program as well	
		 window.setSize(500, 600);	// set window size
		 window.setTitle("Translate");	// set window title	    
		 window.setVisible(true);	// make window visible
		
	}
	
	
	/**
	 * Gets the timer label
	 * @return label
	 */
	public JLabel getTimerLabel() {
		return timerLabel;
	}


	/**
	 * Gets the main JPanel
	 * @return JPanel
	 */
	public JPanel getTopPanel() {
		return topPanel;
	}


	/**
	 * Gets whether the checkbox is checked or not
	 * @return the boolean value
	 */
	public boolean isCheckBox() {
		return checkBox;
	}


	/**
	 * The main window
	 * @return the main window
	 */
	public JFrame getWindow() {
		return window;
	}



	/**
	 * Creates a new interface that displays all the words in a specific dictionary
	 * @return the new interface
	 */
	public JPanel displayAll()
	{
	
		JPanel newPanel = new JPanel(new BorderLayout()); //creates new panel with a border layout
		
		
		/*
		 * Creates the serch field and a label next to it
		 */
		JPanel northPanel = new JPanel();
		northPanel.setLayout(new BoxLayout(northPanel, BoxLayout.LINE_AXIS));
		
		createLabel("Search: ", 100, 30, null, buttonFont, null, northPanel);
		
	
		JTextField search = new JTextField();
		search.setFont(buttonFont);
		search.setToolTipText("Search table");
		
		northPanel.add(search);
		
		newPanel.add(northPanel, BorderLayout.NORTH);
		
		
	
	
	/*
	 * Creates the table with all the words
	 */

	
		//new table
		JTable table = new JTable(toTableModel(dictionary.getEnglish().getDictionary(), "English", "French"));

		
		//adds mouse listener when things are double clicked
		table.addMouseListener(new DisplayList(table,window,dictionary));
		
		//sort the table
		sortTable(table, search);
		
		table.setToolTipText("Double click an item to remove it!");
		//sets row fonts and height
		table.setFont(buttonFont);
		table.setRowHeight(35);
		table.getTableHeader().setFont(buttonFont);
		
		//adds the table to a scroll pane
		JScrollPane pane = new JScrollPane(table);
		
		//adds the table to the main panel
		newPanel.add(pane,BorderLayout.CENTER);
		
		
		/*
		 * creates the panel at the bottom of the window
		 */

		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.LINE_AXIS));
		
		//creates the back button
		JButton button2 = createButton("Back", 100, 40, Color.LIGHT_GRAY, buttonFont, defaultBorder, buttonPanel, new ButtonActionListener(this, topPanel), "toMainMenu");
		button2.setAlignmentX(Component.CENTER_ALIGNMENT);
		buttonPanel.add(Box.createHorizontalGlue());
		//creates the swap button
		JButton button = createButton("Swap", 100, 50, Color.LIGHT_GRAY, buttonFont,defaultBorder, buttonPanel, new ButtonActionListener(table, dictionary,search), "swap table");
		button.setAlignmentX(Component.CENTER_ALIGNMENT);
		buttonPanel.add(Box.createHorizontalGlue());
		
		//creates the add button
		JButton button3 = createButton("Add", 100, 40, Color.LIGHT_GRAY, buttonFont, defaultBorder, buttonPanel, new ButtonActionListener(this,table), "add word");
		button3.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		//adds the button panel to the main panel
		newPanel.add(buttonPanel, BorderLayout.SOUTH);
		return newPanel;
		
		
	}
	
	/**
	 * Creates a new frame that lets the user add new words to dictionaries
	 * @param currentLang the current dictionary
	 * @param translationLang the translation language
	 * @param table the table where all the words are displayed
	 * @param word to be added to the dictionary (optional)
	 * @param list of all words that failed to translated, used only after translating a phrase
	 * @param index the users choice for removing item from a JList
	 */
	public void addItem(String currentLang, String translationLang, JTable table, String word, JList<String> list, int index)
	{
		
		window.setEnabled(false); //disables the main window
		JFrame temp = new JFrame();
		
		//creates main panel
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
		//creates the main language JLabel and text box
		JPanel onTop = new JPanel();
		onTop.setLayout(new BoxLayout(onTop, BoxLayout.X_AXIS));
		createLabel(currentLang, 100, 40, null, buttonFont, null, onTop);
		
		JTextField currentWord = new JTextField();
		currentWord.setFont(buttonFont);
		currentWord.setText(word);
		currentWord.setToolTipText("Main word");
		onTop.add(currentWord);
		
		
		//creates the translation JLabel and text box
		JPanel middle = new JPanel();
		middle.setLayout(new BoxLayout(middle, BoxLayout.X_AXIS)); 
		
		 createLabel(translationLang, 100, 40, null, buttonFont, null, middle);;
		
		JTextField translation = new JTextField();
		translation.setFont(buttonFont);
		translation.setToolTipText("translation");
		middle.add(translation);
		
		
		//Creates the buttons at the bottom of the panel
		JPanel bottom = new JPanel();
		bottom.setLayout(new BoxLayout(bottom, BoxLayout.X_AXIS));
		
		createButton("Cancel", 80, 60, Color.LIGHT_GRAY, buttonFont, defaultBorder, bottom, new ButtonActionListener(temp,window), "cancel");
		bottom.add(Box.createHorizontalGlue());
		createButton("Add", 80, 60, Color.LIGHT_GRAY, buttonFont, defaultBorder, bottom, new ButtonActionListener(currentWord, translation,dictionary,table,currentLang,temp,window, list, index), "add");

		//adds everything to the main panel
		panel.add(onTop);
		panel.add(middle);
		panel.add(bottom);
		
		
		panel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		temp.setContentPane(panel);  // set topPanel as the content pane of this window
		
		temp.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		temp.setLocation(0,topPanel.getSize().height/2); //sets the location to be a bit more in the center
		temp.setSize(500, 200);	// set window size
		temp.setTitle("Add word");	// set window title	    
		temp.setVisible(true);	// make window visible
		
	}
	
	/**
	 * Lets the user choose to remove an item from the list
	 * @param object name1
	 * @param object2 name2
	 * @param window the window that the dialog will appear on
	 * @return users choice
	 */
	public static int removeItem(Object object, Object object2, JFrame window)
	{
		
		String message = "Delete " + object + " - " + object2 + " from dictionary?";
		
		int userChoice = JOptionPane.showConfirmDialog(window, message, "remove item?",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		
		
		
		return userChoice;
	}
	/**
	 * Asks the user to confirm something
	 * @param msg the message
	 * @param title the title of the box
	 * @param window the window
	 * @return users choice
	 */
	public static int userChoice(String msg, String title, JFrame window)
	{
		
		return JOptionPane.showConfirmDialog(window, msg, title, JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		
	}
	
	
	/**
	 * Creates an error message
	 * @param message the message
	 * @param title the title of the dialog
	 * @param curWindow the window that the dialog will appear on
	 */
	public static void errorMsg(String message, String title, JFrame curWindow)
	{
		
		
		JOptionPane.showMessageDialog(curWindow, message, title, JOptionPane.INFORMATION_MESSAGE);

	}


	

	/**
	 * Some of the code taken from stackOverflow to convert a map to a jTable.
	 * Also prevents the user from editing the table
	 * @param map the HashMap that will be converted
	 * @param left the left side of the table
	 * @param right the right side of the table
	 * @return the model of the JTable
	 */
	public static TableModel toTableModel(HashMap<?,?> map, String left, String right) {
	    DefaultTableModel model = new DefaultTableModel(
	        new Object[] { left, right }, 0
	    )
	    		{
	    	
	    	
			private static final long serialVersionUID = 1L;

			//
			//Prevents the user from editing cells in the table
			//
	@Override
    public boolean isCellEditable(int row, int col)
    { return false; }
	    		};
	
	    		
	    for (HashMap.Entry<?,?> entry : map.entrySet()) {
	        model.addRow(new Object[] { entry.getKey(), entry.getValue() });
	    }
	    return model;
	}
	
	/**
	 * Sorts the table and adds a document listener to the search bar
	 * @param table the JTable where all the words of the dictionary are located
	 * @param search the search bar
	 */
	public static void sortTable(JTable table, JTextField search)
	{
		//creates a sorter for the table
		TableRowSorter<TableModel> sorter 
	    = new TableRowSorter<TableModel>(table.getModel());
		//sets the sorter
		table.setRowSorter(sorter);
		
		//makes all items in the table be sorted alphabetically by default
		ArrayList<RowSorter.SortKey> sortKeys = new ArrayList<>();	
		sortKeys.add(new RowSorter.SortKey(0, SortOrder.ASCENDING));
		sorter.setSortKeys(sortKeys);
		
		//creates a listener that changes the table every time a value is changed
		search.getDocument().addDocumentListener(new DisplayList(search,sorter));
	}

	/**
	 * Creates the main menu interface
	 * @return the main menu
	 */
	public JPanel mainMenu()
	{
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.PAGE_AXIS));
		buttonPanel.add(Box.createVerticalGlue());
		JLabel label = createLabel("DICTIONARY", 150, 40, null, buttonFont, null, buttonPanel);
		label.setAlignmentX(Component.CENTER_ALIGNMENT);
		buttonPanel.add(Box.createRigidArea(new Dimension(0, 40)));
		JButton button1 = createButton("Translate phrase", 150, 50, Color.LIGHT_GRAY, buttonFont, defaultBorder, buttonPanel,new ButtonActionListener(this,topPanel),"translateMenu");
		button1.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		buttonPanel.add(Box.createRigidArea(new Dimension(0,10)));
		
		JButton button2 = createButton("Display dictionary", 150, 50, Color.LIGHT_GRAY, buttonFont, defaultBorder, buttonPanel,new ButtonActionListener(this,topPanel),"displayAll");
		button2.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		buttonPanel.add(Box.createRigidArea(new Dimension(0,10)));
		
		JButton button3 = createButton("Translate from file", 150, 50, Color.LIGHT_GRAY, buttonFont, defaultBorder, buttonPanel,new ButtonActionListener(window,this, dictionary), "read from file");
		button3.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		buttonPanel.add(Box.createRigidArea(new Dimension(0,10)));
		
		JButton button4 = createButton("Exit", 150, 50, Color.LIGHT_GRAY, buttonFont, defaultBorder, buttonPanel,new ButtonActionListener(null, window), "exit");
		button4.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		buttonPanel.add(Box.createVerticalGlue());
		
		return buttonPanel;
		
	}
	/**
	 * Template for creating a JButton
	 * @param text the text of the button
	 * @param dimensionx the size x of button
	 * @param dimensiony the size y of button
	 * @param background the background color of jbutton
	 * @param font the font of button
	 * @param border the borders
	 * @param panel the panel that will contain the button
	 * @param action the action listner of the button
	 * @param command the action command of the button
	 * @return the button
	 */
	public JButton createButton(String text, int dimensionx, int dimensiony, Color background,Font font,Border border,JPanel panel, ActionListener action, String command)
	{
		JButton button;
		button = new JButton(text);
		button.setPreferredSize(new Dimension(dimensionx,dimensiony));
		button.setVisible(true);
		button.setEnabled(true);
		button.setBackground(background);
		button.setBorder(border);
		button.setFont(font);
		button.addActionListener(action);
		button.setActionCommand(command);
		panel.add(button);

		return button;
	}
	/**
	 * Creates a new label
	 * @param text the text of the label
	 * @param dimensionx the size of the label
	 * @param dimensiony the size
	 * @param background the background color
	 * @param font the font 
	 * @param border the border
	 * @param panel the panel that will contain the button
	 * @return the new Label
	 */
	public JLabel createLabel(String text, int dimensionx, int dimensiony, Color background,Font font,Border border,JPanel panel)
	{
		JLabel label;
		label = new JLabel(text);
		label.setPreferredSize(new Dimension(dimensionx,dimensiony));
		label.setVisible(true);
		label.setEnabled(true);
		label.setBackground(background);
		label.setBorder(border);
		label.setFont(font);
	
		panel.add(label);

		return label;
	}
	/**
	 * Creates the Translate interface
	 * @param text the text that will be translated
	 * @return the new interface
	 */
	public JPanel translate(String text)
	{
		JPanel mainLayout = new JPanel();
		mainLayout.setLayout(new BorderLayout());
		checkBox = false;
		
		//main panel
		JPanel translateTextLayout = new JPanel();
		translateTextLayout.setLayout(new BoxLayout(translateTextLayout, BoxLayout.PAGE_AXIS));
		
		//Top panel containing the Label and textArea for translating
		JPanel topLayout = new JPanel();
		topLayout.setLayout(new BoxLayout(topLayout, BoxLayout.LINE_AXIS));
		
		JLabel label = createLabel("English", 100, 50, Color.WHITE, buttonFont, null, topLayout);
		topLayout.add(Box.createHorizontalGlue());
		
		//creates a checkbox
		JCheckBox addWords = new JCheckBox("Add words if not found");
		addWords.setMnemonic(KeyEvent.VK_C); 
		 addWords.setSelected(false);
		 addWords.addItemListener(this);
		 
		 topLayout.add(addWords);
		 
		 translateTextLayout.add(topLayout);
		
		label.setAlignmentX(Component.LEFT_ALIGNMENT);
		
		//text are that will be translated
		JTextArea textField = new JTextArea(7,1);
		textField.setWrapStyleWord(true);
		textField.setLineWrap(true);
		textField.setText(text);
		
		textField.setFont(textBoxFont);
		JScrollPane scrollPane = new JScrollPane(textField);
		//add text area to scrollpane
		translateTextLayout.add(scrollPane);
	
		mainLayout.add(translateTextLayout,BorderLayout.NORTH);
		
		
		
		//Swap button and timer layout
		JPanel temp = new JPanel();
		temp.setLayout(new BoxLayout(temp, BoxLayout.LINE_AXIS));
		
		
		//creates the button
		
		JButton swapBtn = createButton("swap", 80, 60, Color.LIGHT_GRAY, buttonFont, defaultBorder, temp, null,"swap");
		swapBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
		temp.add(Box.createHorizontalGlue());
		
		//creates the Label for showing the time
		if(text != "")
		{
		JLabel timerText = createLabel("Speed:", 80, 30, null, buttonFont, null, temp);
		timerLabel = createLabel("", 160, 30, null, buttonFont, null, temp);
		timerLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
		timerText.setAlignmentX(Component.LEFT_ALIGNMENT);
		}
		temp.add(Box.createHorizontalGlue());
		mainLayout.add(temp, BorderLayout.CENTER);
		
		
		
		//creates the translation area
		JPanel translatedWord = new JPanel();
		translatedWord.setLayout(new BoxLayout(translatedWord, BoxLayout.PAGE_AXIS));
		
		JLabel label2 = createLabel("French", 100, 50, Color.WHITE, buttonFont, null, translatedWord);
		label2.setAlignmentX(Component.LEFT_ALIGNMENT);
		
		
	
		JTextArea textField2 = new JTextArea(7,1);
		textField2.setLineWrap(true);
		textField2.setEditable(false);
		
		textField2.setFont(textBoxFont);
		JScrollPane scrollPane2 = new JScrollPane(textField2);
		
		translatedWord.add(scrollPane2);
		
		
		//ADDS ACTION LISTENER TO SWAP BUTTON
		swapBtn.addActionListener(new ButtonActionListener(textField,textField2,label,label2,dictionary,this));
		
		//creates the buttons
		JPanel buttons = new JPanel();
		buttons.setLayout(new BoxLayout(buttons, BoxLayout.LINE_AXIS));
		
		//back button
		createButton("Back", 150, 50, Color.LIGHT_GRAY, buttonFont, defaultBorder, buttons, new ButtonActionListener(this,topPanel),"toMainMenu");
		buttons.add(Box.createHorizontalGlue());
		//translate button
		createButton("Translate", 150, 50, Color.LIGHT_GRAY, buttonFont, defaultBorder, buttons, new ButtonActionListener(textField,textField2,label,label2,dictionary,this), "translate");
	
		translatedWord.add(buttons);
		mainLayout.add(translatedWord,BorderLayout.SOUTH);
		return mainLayout;
	}
	
	/**
	 * Creates the interface for displaying untranslated words
	 * @param curLang the current language that the words were translated
	 * @param translationLang the translation language
	 * @return the new interface
	 */
	public JPanel untranslatedWords(String curLang, String translationLang)
	{
		String[] unrecognisedWords = dictionary.getUntranslatedWordArray(); //gets the array of all untranslated words
		JPanel main = new JPanel();
		main.setLayout(new BorderLayout());
		JLabel label1 = createLabel("Double click a word you wish to add", 500, 30, null, buttonFont, null, main); //guide
		main.add(label1, BorderLayout.NORTH);
		
		//creates a new list
		DefaultListModel<String> listModel = new DefaultListModel<String>();
		JList<String> list = new JList<String>(listModel);
		
		// adds all the items inside the array to the list
		for(int x = 0; x < unrecognisedWords.length;x++)
		{
			listModel.addElement(unrecognisedWords[x]);
			
		}
		
		
		
		list.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		list.setFont(textBoxFont);
		list.setVisibleRowCount(-1);
		
		//adds a new mouse adapter to the list, that will react when items are double clicked
		list.addMouseListener(new MouseAdapter() {
			
			@Override
			/**
			 * Overrides mouseClicked event on mouseAdapter
			 */
			public void mouseClicked(MouseEvent e) {
				
				if (e.getClickCount() == 2) {
					
					int index =	list.getSelectedIndex();
					if(index != -1)
					{
						String selection = list.getSelectedValue();
						addItem(curLang, translationLang, null,selection,list,index); //opens the addItem box
						
					}
					
				}
				
			}
			
		});
		JScrollPane listScroller = new JScrollPane(list);
		main.add(listScroller, BorderLayout.CENTER);
		
		//Adds a button to return to the main menu at the bottom
		JPanel bottom = new JPanel();
		bottom.setLayout(new BoxLayout(bottom, BoxLayout.LINE_AXIS));
		createButton("Back", 150, 50, Color.LIGHT_GRAY, buttonFont, defaultBorder, bottom, new ButtonActionListener(this,topPanel),"toMainMenu");
		bottom.add(Box.createHorizontalGlue());
		
		main.add(bottom,BorderLayout.SOUTH);
		
		return main;
	}
	/**
	 * Changes the screen to untranslated wordList
	 * @param curLang the current language
	 * @param translationLang the translation language
	 */
	public void changeToUntranslatedWordList(String curLang, String translationLang)
	{
		topPanel.removeAll();
		topPanel.add(untranslatedWords(curLang,translationLang), BorderLayout.CENTER);
		topPanel.revalidate();
	}
	/**
	 * Opens a file chooser
	 * @param window the window that will contain the file chooser
	 * @return the selected file
	 */
	public static File fileChooser(JFrame window)
	{
		JFileChooser fc = new JFileChooser();
		FileFilter filter = new FileNameExtensionFilter("txt", "txt", "TXT"); //shows only txt items
		
		fc.setFileFilter(filter);
		
	    int returnVal = fc.showOpenDialog(window);
	 

        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            return file;
           
     
        } else {
        	return null;
        }
		
	}


	@Override
	/**
	 * Checks to see if the state of the checkbox changed
	 */
	public void itemStateChanged(ItemEvent arg0) {
		// TODO Auto-generated method stub
		 if (arg0.getStateChange() == ItemEvent.DESELECTED) {
	           checkBox = false;
	       } else  if (arg0.getStateChange() == ItemEvent.SELECTED) {
		       checkBox = true;
		   }
		
	}
}
