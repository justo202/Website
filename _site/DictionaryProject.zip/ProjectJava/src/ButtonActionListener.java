import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import javax.swing.table.DefaultTableModel;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;

/**
 * Creates methods for every button
 * @author Justas Labeikis
 *
 */
public class ButtonActionListener implements ActionListener {
	
	private GUI gui; //the gui class
	private JPanel mainPanel; //the panel that's the plane of the main frame
	private JFrame frame; //a JFrame
	private JFrame mainFrame; //the main JFrame
	private JTable table; //the JTable where all the words are displayed
	private JTextField textField1, textField2; //text fields for translating and adding text
	private JTextArea mainText, translateText; 
	private JLabel label1, label2; //labels
	private TextTranslation dictionary; // the dictionary class
	private Object language1; //the languages
	private JLabel timerText; //the text of the time

	
	private JList<String> list; //list of untranslated words
	private int listIndex; //the selected word from the list
	
	
    private static Color  HILIT_COLOR = Color.yellow; //color for highlighting
    
    private Highlighter hilit; //the highlighter
    private Highlighter.HighlightPainter painter; //the painter
    
	
	/**
	 * Creates a button for changing the menu screen
	 * @param currentGui the GUI class
	 * @param panel the top panel
	 */
	public ButtonActionListener(GUI currentGui, JPanel panel)
	{
		gui = currentGui;
		mainPanel = panel;
	}

	
	public ButtonActionListener(JFrame curFrame, JFrame main)
	{
		frame = curFrame;
		mainFrame = main;
		
	}
	/**
	 * Swaps the languages displayed on the table
	 * @param tab the table
	 * @param translate the reference to the dictionaries
	 * @param find the search bar
	 */
	public ButtonActionListener(JTable tab, TextTranslation translate, JTextField find)
	{
		table = tab;
		dictionary = translate;
		textField1 = find;
		
	}

	/**
	 * Adds a new word to a specific dictionary
	 * @param field1 text in cur language
	 * @param field2 translation
	 * @param translate the dictionary
	 * @param tab the name of the current language
	 * @param lang the main language
	 * @param curFrame the window
	 * @param main main window
	 * @param curList the list of untranslated words
	 * @param index user selected index
	 */
	public ButtonActionListener(JTextField field1, JTextField field2, TextTranslation translate,JTable tab, Object lang, JFrame curFrame, JFrame main, JList<String> curList, int index)
	{
		textField1 =field1;
		textField2 = field2;
		dictionary = translate;
		language1 = lang;
		table = tab;
		list = curList;
		frame = curFrame;
		mainFrame = main;
		listIndex = index;
	}
	
	/**
	 * Used for creating the add word window
	 * @param curGui the main gui
	 * @param optional the table with all the words in it
	 */
	public ButtonActionListener(GUI curGui, JTable optional)
	{
		gui = curGui;
		table = optional;
	}
	
	/**
	 * 
	 * Swaps the languages used for translating user input and translates userInput
	 * @param field1 text field of the words to be translated
	 * @param field2 text field of the translation
	 * @param curLabel1 the main language
	 * @param curLabel2 the translation language
	 * @param curTextTranslation the dictionary
	 * @param curGui the main gui
	 */
	public ButtonActionListener(JTextArea field1, JTextArea field2, JLabel curLabel1, JLabel curLabel2, TextTranslation curTextTranslation, GUI curGui)
	{
		label1 = curLabel1;
		label2 = curLabel2;
		mainText = field1;
		translateText = field2;
		dictionary = curTextTranslation;
		gui = curGui;
		
		  hilit = new DefaultHighlighter();
	        painter = new DefaultHighlighter.DefaultHighlightPainter(HILIT_COLOR);
	        translateText.setHighlighter(hilit);
	
		
	}
	/**
	 * Opens a file chooser dialog for the user
	 * @param window the frame that the dialog will open in
	 * @param curGui the current gui
	 * @param translate the dictionary
	 */
	public ButtonActionListener(JFrame window, GUI curGui, TextTranslation translate)
	{
		mainFrame = window;
		gui =curGui;
		dictionary = translate;
	}
	
	@Override
	
	/**
	 * Checks which button is pressed
	 */
	public void actionPerformed(ActionEvent e) {
		if("translateMenu".equals(e.getActionCommand())) //translate
		{
			mainPanel.removeAll();
			mainPanel.add(gui.translate(""), BorderLayout.CENTER);
			mainPanel.validate();
			
		}
		else if("swap".equals(e.getActionCommand())) //swaps languages in translate
		{
			String temp = label1.getText();
			
			translateText.setText("");
			label1.setText(label2.getText());
			label2.setText(temp);
			
			
			
		}
		else if("swap table".equals(e.getActionCommand())) //swaps languages in table
		{
			Object temp = table.getColumnName(0); //get value at top left space of the table, which will be one of the languages
			
			if(temp.equals("English"))
			{
				table.setModel(GUI.toTableModel(dictionary.getFrench().getDictionary(), "French", "English"));
				GUI.sortTable(table, textField1);
				textField1.setText("");
				table.revalidate();
				
				
			}
			else if(temp.equals("French"))
			{
				table.setModel(GUI.toTableModel(dictionary.getEnglish().getDictionary(), "English", "French"));
				GUI.sortTable(table, textField1);
				textField1.setText("");
				table.revalidate();
			}
		}
		else if("toMainMenu".equals(e.getActionCommand())) //goes back to main menu
		{
			mainPanel.removeAll();
			mainPanel.add(gui.mainMenu());
			mainPanel.validate();
		}
		else if("displayAll".equals(e.getActionCommand())) //goes to display all words interface
		{
			mainPanel.removeAll();
			mainPanel.add(gui.displayAll(), BorderLayout.CENTER);
			mainPanel.validate();
		}
		else if("cancel".equals(e.getActionCommand()))  //exits the frame
		{
			mainFrame.setEnabled(true);
			frame.dispose();
			
		}
		else if("add word".equals(e.getActionCommand()))  //opens a new window to add a new word
		{
			String lang1 = table.getColumnName(0);
			String lang2 = table.getColumnName(1);
			gui.addItem(lang1, lang2, table,"",null, 0);
			
		}
		else if("add".equals(e.getActionCommand())) //adds a word to a specific dictionary
		{
			addWordTable();
		
		}
		else if("translate".equals(e.getActionCommand())) //translate text
		{
			translateWords();
		
			
		}
		else if("read from file".equals(e.getActionCommand())) //reads text from a file
		{
			File file = GUI.fileChooser(mainFrame);
			String text = dictionary.readFromFile(file);
			
			if(text.equals("Error"))
			{
				GUI.errorMsg("Failed to read from file!", "Error", mainFrame);
			}
			else if(!text.isEmpty())
			{
				JPanel panel = gui.getTopPanel();
				
				panel.removeAll();
				panel.add(gui.translate(text), BorderLayout.CENTER);
				panel.validate();
			}
		}
		else if("exit".equals(e.getActionCommand())) //reads text from a file
		{
			mainFrame.dispose();
			System.exit(0);
		}
		
	}
	
	/**
	 * Translates and displays the translation to a text area
	 */
	public void translateWords()
	{
		String content = mainText.getText(); //the content to translate
		if(!content.isEmpty())
		{
		
			String[] translatedWords = dictionary.translateText(content,label1.getText()); //translates each word and puts it in the array
			String translatedContent ="";
			String translationTime = String.valueOf(dictionary.getWordsPerSecond() + " w/s");
			timerText = gui.getTimerLabel();
			if(timerText != null)
			timerText.setText(translationTime);
			
			/*
			 * Uses an array to add words to the textArea
			 */
			for(int x = 0; x <translatedWords.length;x++)
			{
			
				translatedContent+=translatedWords[x];
			
				translatedContent+=" ";
				

			}
			translateText.setText(translatedContent);
			highlightText(translatedContent);

			
			
			//is checkbox is checked, and there are words that failed to translate and the user choose yes when asked to add new words
			if(gui.isCheckBox() && !dictionary.translationSuccess() && GUI.userChoice("Some words failed to tranlsate, would you like to add them?", "Translation failed", gui.getWindow()) == JOptionPane.YES_OPTION)
			{
				gui.changeToUntranslatedWordList(label1.getText(), label2.getText()); // add a new word
				
			}
		}
	}
	
	/**
	 * Highlights the words that failed to translate
	 * @param translatedContent the translated content
	 */
	public void highlightText(String translatedContent)
	{
		String[] wrongWords = dictionary.getUntranslatedWordArray(); //gets the array of failed words
		String word; 
		int position = 0;
		int end;
		for(int x = 0; x < wrongWords.length;x++)
		{
			word = wrongWords[x]; //gets a word from the array
			if(!word.isEmpty()) //if word isn't ""
			{
				
				position = translatedContent.indexOf(word, position); //finds the nearest position of that word
				try {
				while(position >= 0) //if position is less than 0 that means it failed to find a word
				{
						
						end = position + word.length(); //gets the index of where the word ends
						if(end < translatedContent.length()-1)
						{
						
							
							if(position > 0 && translatedContent.charAt(position-1) == ' ' && (translatedContent.charAt(end) == ' ' || translatedContent.charAt(end) == '.' || translatedContent.charAt(end) == '?' || translatedContent.charAt(end) == '!'))
							{
								
								hilit.addHighlight(position, end, painter); //highlights the area of the word
							}
							else if(position == 0 && (translatedContent.charAt(end) == ' ' || translatedContent.charAt(end) == '.' || translatedContent.charAt(end) == '?' || translatedContent.charAt(end) == '!'))
							{
								hilit.addHighlight(position, end, painter); //highlights the area of the word
							}
						}
						else
						{
							hilit.addHighlight(position, end, painter); //highlights the area of the word
						}
						
						position+=end; //increases position so it wouldn't get the same word again
						position = translatedContent.indexOf(word, position); //finds another word
	
					
				}
				
				} catch (BadLocationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
			
		}
		
	}

	
	
	
	/**
	 * Adds words to a specific dictionary
	 */
	public void addWordTable()
	{
		if((!textField1.getText().isEmpty() && !textField2.getText().isEmpty())) //checks if both text fields are not empty
		{
			String mainPhrase; //the phrase to be added to the dictionary
			String translation; //the translation
			mainPhrase = textField1.getText().toLowerCase();
			translation = textField2.getText().toLowerCase();
			
			if(language1.equals("English") && !dictionary.getEnglish().hasWord(mainPhrase)) //if its a english dictionary
			{
				//adds the phrase to the hashmap of english words
				dictionary.addToTranslation(mainPhrase, translation, dictionary.getEnglish());
			
				if(table != null) //if its a table
				{
					//gets the model of the table and adds a new row
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					model.addRow(new Object[]{mainPhrase,translation});
					
					//refreshes the table to see the changes
					table.revalidate();

				}
				else //if its a list
				{
					
					DefaultListModel<String> model = (DefaultListModel<String>) list.getModel(); //gets the model of the list
					model.removeElementAt(listIndex); //removes the element
					
				}
				
				
				mainFrame.setEnabled(true);
				frame.dispose();
				
				
			}
			else if(language1.equals("French") && !dictionary.getFrench().hasWord(mainPhrase)) //if its a french dictionary
			{
				//adds the phrase to the hashmap of french words
				dictionary.addToTranslation(mainPhrase, translation, dictionary.getFrench());
				
				if(table != null) //if its a table
				{
					//gets the model of the table and adds a new row
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					model.addRow(new Object[]{mainPhrase,translation});
					
					//refreshes the table
					table.revalidate();
				
					
				}
				else //if it's a list
				{
					DefaultListModel<String> model = (DefaultListModel<String>) list.getModel(); //gets the model of the list
					model.removeElementAt(listIndex); //removes the element
				}
				
				//closes the add word frame
				mainFrame.setEnabled(true);
				frame.dispose();
			}
			else //if the word is already in the dictionary
			{
				GUI.errorMsg("Word already exists!", "Error", frame);
				
				
			}
	
		}
		else //if text fields are empty
		{
			//display error message if the text fields are empty
			GUI.errorMsg("Text fields cannot be empty!", "Error!",frame);
			
		}
	}
	
}
