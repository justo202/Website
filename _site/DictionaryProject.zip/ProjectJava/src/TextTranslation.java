import java.util.HashSet;
import java.util.Set;
import java.util.Date;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.File;

/**
 * Represents Text Translation of Language Translator
 * 
 * @author Jokubas Butkus
 * @version v1.0
 */
public class TextTranslation 
{
	private Translation english;
	private Translation french;
	private Set<String> untranslatedWords;
	private long translationTime;
	private double translationTimeSeconds;
	private long wordsPerSecond;
	private final String[] SYMBOLS = new String[] {",", "-", "+", "=", "/", "(", ")", "'", ":"};
	private final String[] PUNCTUATION_MARK = new String[] {".", "?", "!", "\""};
	private final char COMMA = ',';
	
	
	/**
	 * Default constructor
	 */
	public TextTranslation()
	{
		english = new Translation("english-french.txt");
		french = new Translation("french-english.txt");
		untranslatedWords = new HashSet<String>();
	}
	
	/**
	 * Get English to French dictionary
	 * 
	 * @return English - French dictionary
	 */
	public Translation getEnglish()
	{
		return english;
	}
	
	/**
	 * Get French to English dictionary
	 * 
	 * @return French - English dictionary
	 */
	public Translation getFrench()
	{
		return french;
	}
	

	public boolean translationSuccess()
	{
		
		return untranslatedWords.isEmpty();
		
	}
	
	public String[] getUntranslatedWordArray()
	{
		int size = untranslatedWords.size();
		
		return untranslatedWords.toArray(new String[size]);
	}
	
	/**
	 * Get the time of the translation process
	 * 
	 * @return Time of translation
	 */
	public long getTranslationTime()
	{
		return translationTime;
	}
	
	public double getTranslationTimeSeconds()
	{
		return translationTimeSeconds;
	}
	/**
     * Get words per second
     * 
     * @return Translated words per second
     */
    public double getWordsPerSecond()
    {
        return wordsPerSecond;
    }
    /**
	 * Translate given text from selected language to another
	 * @param text Text to be translated
	 * @param selectedLanguage Language from which to translate
	 * @return Array of translated words
	 */
	public String[] translateText(String text, String selectedLanguage)
	{
		// Get time of start of translation
		Date startTime = new Date();
		
		String[] wordArray;
		String expression = " ";
		String[] translatedArray = null;
		Translation foundLanguage = null;
		int amountOfWords;
		
		if (selectedLanguage.equals("English"))
		{
			foundLanguage = english;
		}
		if (selectedLanguage.equals("French"))
		{
			foundLanguage = french;
		}
		
		// Lower case whole text
		text = text.toLowerCase();
		
		// Remove commas in the text
		//text = replaceCommas(text);
		
		text = replaceSymbols(text);
		
		text = replaceLines(text);
		
		text = addSpaceToMarks(text);
		
		// Clear set of untranslated words
		untranslatedWords.clear();
		
		// Split text into separate words
		wordArray = text.split(expression);
		
		amountOfWords = wordArray.length;
		
		// If language is recognised
		if (foundLanguage != null)
		{
			// Define translatedArray size same as wordArray
			translatedArray = new String[wordArray.length];
			
			for (int i=0; i<wordArray.length; i++)
			{
				// If word contains numbers
				if (containsNumbers(wordArray[i]))
				{
					// Do not translate
					translatedArray[i] = wordArray[i];
				}
				// If word does not contain numbers
				else
				{
					String mark = "";
					
					// Check for punctuation marks at the end of the word
					for (int j=0; j<PUNCTUATION_MARK.length; j++)
					{
						// If there is a punctuation mark after the word
						if (wordArray[i].endsWith(PUNCTUATION_MARK[j]))
						{
							// remove last char of the word
							wordArray[i] = wordArray[i].substring(0, wordArray[i].length()-1);
							
							// Set mark to the one that was in the end of a word
							mark = PUNCTUATION_MARK[j];
						}
					}
					
					// If the word can be translated
					if (foundLanguage.hasWord(wordArray[i]))
					{
						// Translate word
						translatedArray[i] = foundLanguage.getTranslation(wordArray[i]);
					}
					// If the word cannot be translated
					else
					{
						// Try to translate a phrase made of two words
						if (i+1 < wordArray.length)
						{
							String phrase;
							// Add two words to make a phrase
							phrase = wordArray[i].concat(" ").concat(wordArray[i+1]);
							// If a phrase is in the dictionary
							if (foundLanguage.hasWord(phrase))
							{
								translatedArray[i] = foundLanguage.getTranslation(phrase);
								i++;
							}
							// If a phrase was not found in dictionary
							else
							{
								// Add untranslated word to translated array
								translatedArray[i] = wordArray[i];
								// Add the word to set of untranslated words
								if (!wordArray[i].equals(""))
								{
									untranslatedWords.add(wordArray[i]);
								}
							}
						}
						// If a phrase can not be made because there are no more words
						else
						{
							// Add untranslated word to translated array
							translatedArray[i] = wordArray[i];
							// Add the word to set of untranslated words
							if (!wordArray[i].equals(""))
							{
								untranslatedWords.add(wordArray[i]);
							}
						}
					}
					
					// add mark (or nothing if there was no mark) to the end of translated word
					if (translatedArray[i] != null)
					{
						translatedArray[i] = translatedArray[i].concat(mark);
					}
					// If word is null (can happen if phrase is translated)
					else
					{
						translatedArray[i] = "";
					}
				}
			}
		}
		// If language is not recognised
		else
		{
			translatedArray = wordArray;
		}
		
		// Get time after completing translation
		Date finishTime = new Date();
		// Calculate time of translation in miliseconds
		long translationTime = finishTime.getTime() - startTime.getTime();
		
		long translationTimeSeconds = translationTime;
		double toSeconds = 1000;
		
		//translationTimeSeconds = translationTime / toSeconds;
		if(translationTimeSeconds > 0)
		wordsPerSecond = amountOfWords * 1000 / translationTimeSeconds;
		
		return translatedArray;
	}
	
	/**
	 * Remove commas from the text
	 * @param text Text from which to remove commas
	 * @return Text without  commas
	 */
	public String replaceCommas(String text)
	{
		text = text.replace(COMMA, ' ');
		
		// replace two spaces with one
		text = text.replace("  ", " ");
		
		return text;
	}
	
	/**
	 * Removes lines from text
	 * @param text text
	 * @return text without new lines
	 */
	public String replaceLines(String text)
	{
		text = text.replace("\r\n", " ");
		
		text = text.replace("\n", " ");
		
		// replace two spaces with one
		text = text.replace("  ", " ");
		
		return text;
	}
	/**
	 * Replaces some symbols with spaces
	 * @param text the text to be replaced
	 * @return the new text
	 */
	public String replaceSymbols(String text)
	{
		for (int i=0; i<SYMBOLS.length; i++)
		{
			text = text.replace(SYMBOLS[i], " ");
		}
		
		// replace two spaces with one
		text = text.replace("  ", " ");
		
		return text;
	}
	/**
	 * Adds spaces to punctuation marks
	 * @param text the text to be changed
	 * @return the new text
	 */
	public String addSpaceToMarks(String text)
	{
		for (int i=0; i<PUNCTUATION_MARK.length; i++)
		{
			text = text.replace(PUNCTUATION_MARK[i], PUNCTUATION_MARK[i] + " ");
		}
		
		// replace two spaces with one
		text = text.replace("  ", " ");
		
		return text;
	}
	/**
	 * Check if the string contains a number digit
	 * @param word the word to be checked
	 * @return if the word contains a number
	 */
	public boolean containsNumbers(String word)
	{
		boolean containsNum = false;
		for (int i=0; i<=9; i++)
		{
			containsNum = word.contains(String.valueOf(i));
			if (containsNum == true)
			{
				break;
			}
		}
		return containsNum;
	}
	/**
	 * Adds to a dictionary
	 * @param word word to be added
	 * @param meaning its meaning
	 * @param language the dictionary
	 */
	public void addToTranslation(String word, String meaning, Translation language)
	{
		language.addToHashMap(word, meaning);
		language.saveToFile(true, word);
	}
	
	/**
	 * Removes a word from a dictionary
	 * @param lang the language
	 * @param word the word
	 */
	public void removeWord(String lang, String word)
	{
		if(lang.equals("English"))
		{
			english.deleteFromMap(word);
			english.saveToFile(false, "");
		}
		else if(lang.equals("French"))
		{
			french.deleteFromMap(word);
			french.saveToFile(false, "");
		}
		
		
	}
	/**
	 * Reads text from a file and returns it
	 * @param file the file to be read
	 * @return string of the text
	 */
	public String readFromFile(File file)
	{
		if(file != null)
		{
		if(file.exists() && file.canRead() && file.getName().contains(".txt"))
		{
			String content = "";
			FileReader fileReader = null;
			BufferedReader bufferedReader = null;
			
			//try copying the node details from the Sample file if verified to exist
			//and there are no errors to be caught
			try 
			{
				
				fileReader = new FileReader(file);
				bufferedReader = new BufferedReader(fileReader);
				
				String nextLine = bufferedReader.readLine();
				
				//loop until there is no line of details to copy
				while(nextLine!=null) 
				{
					content+=nextLine + " ";
					nextLine = bufferedReader.readLine();
					
				}
				bufferedReader.close();
				return content;
			}catch (IOException e) 
			{
				// TODO Auto-generated catch block
				System.out.println("The error is: "+e);
			}
		}
		return "Error";
		}
		return "";
	
	}
}

