
public class MainMenu {

	public static void main(String[] args) {
		
		
		
		// TODO Auto-generated method stub
		javax.swing.SwingUtilities.invokeLater(new Runnable()
		{
			public void run()
			{
				runprogram();
			}
		});
	}
	public static void runprogram()
	{
		GUI gui = new GUI(new TextTranslation());
	}
}
