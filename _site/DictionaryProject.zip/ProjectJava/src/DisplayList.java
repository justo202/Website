
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashMap;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;


public class DisplayList extends MouseAdapter implements DocumentListener {
	
	private JTable tab; //the main table
	private JFrame mainWindow; //the main window
	private JTextField search; //the search field
	private TableRowSorter<TableModel> sorter; //the sorter for the table
	private TextTranslation dictionary; // the dictionary
	
	/**
	 * Displays the dictionary on a table
	 * @param table the table
	 * @param window the window that the table is in
	 * @param curDictionary the dictionary
	 */
	public DisplayList(JTable table, JFrame window, TextTranslation curDictionary)
	{
		super();
		tab = table;
		mainWindow = window;
		dictionary = curDictionary;
		
		
	}
	/**
	 * Makes the table sort every time the search box is updated
	 * @param textSearch the search box
	 * @param currSorter the sorter for the table
	 */
	  public DisplayList(JTextField textSearch, TableRowSorter<TableModel> currSorter)
	  {
		  search = textSearch;
		  sorter = currSorter;
		  
		  
	  }
	
	  
	@Override
	/**
	 * Overrides mouseClicked event on mouseAdapter
	 */
	public void mouseClicked(MouseEvent e) {
		
		int userChoice;
		  if (e.getClickCount() == 2) {
		      
		      int row = tab.getSelectedRow();		     
		      
		 userChoice = GUI.removeItem(tab.getValueAt(row, 0), tab.getValueAt(row, 1), mainWindow); //asks the user if he wishes to remove an item
		   
		   if(userChoice == JOptionPane.YES_OPTION)
		   {
				String curLang = tab.getColumnName(0);
				dictionary.removeWord(curLang, tab.getValueAt(row, 0).toString());
				   DefaultTableModel model =(DefaultTableModel) tab.getModel();
				   
				   //Easiest way to do this would be to just use the model to remove a row and update it, however that method does not work for some reason
				   
				   model.setRowCount(0); //removes all data from the table

				   
				 //checks which language is used and inserts the new dictionaries and re adds all the items
				   if(curLang.equals("English")) 
				   {
				   for (HashMap.Entry<?,?> entry : dictionary.getEnglish().getDictionary().entrySet()) {
				        model.addRow(new Object[] { entry.getKey(), entry.getValue() });
				    }
				   }
				   else if (curLang.equals("French"))
				   {
					   for (HashMap.Entry<?,?> entry : dictionary.getFrench().getDictionary().entrySet()) {
					        model.addRow(new Object[] { entry.getKey(), entry.getValue() });
					    } 
				   }
				  
				GUI.errorMsg("Item deleted!", "Success!", mainWindow);
				
				
				
		   }
		   
		   }
		
	}


	
	@Override
	public void changedUpdate(DocumentEvent arg0) {
		newFilter(search, sorter);
		
	}


	@Override
	public void insertUpdate(DocumentEvent arg0) {
		newFilter(search, sorter);
		
	}


	@Override
	public void removeUpdate(DocumentEvent arg0) {
		newFilter(search, sorter);
		
	}


	/**
	 * Filters text every time the search box text changes
	 * @param filterText text field that the user will write to
	 * @param sorter the sorter that sorts the table
	 */
	private void newFilter(JTextField filterText, TableRowSorter<TableModel> sorter) {
	    RowFilter<TableModel, Object> rf = null;
	    //If current expression doesn't parse, don't update.
	    try {
	        rf = RowFilter.regexFilter(filterText.getText(), 0);
	    } catch (java.util.regex.PatternSyntaxException e) {
	        return;
	    }
	    sorter.setRowFilter(rf);
	}


}
